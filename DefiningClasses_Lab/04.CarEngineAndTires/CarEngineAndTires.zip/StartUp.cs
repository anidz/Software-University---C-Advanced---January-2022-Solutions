﻿using System;

namespace _04.CarEngineAndTires
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

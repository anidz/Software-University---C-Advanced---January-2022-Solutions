﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Car
{
    class Car
    {
    }
}

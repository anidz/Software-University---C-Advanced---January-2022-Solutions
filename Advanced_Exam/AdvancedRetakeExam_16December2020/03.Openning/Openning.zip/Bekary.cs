﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Openning
{
    class Bekary
    {
    }
}
